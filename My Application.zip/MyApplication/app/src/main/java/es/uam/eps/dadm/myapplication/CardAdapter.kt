package es.uam.eps.dadm.cards

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import es.uam.eps.dadm.myapplication.Card
import es.uam.eps.dadm.myapplication.R

class CardAdapter : RecyclerView.Adapter<CardAdapter.CardHolder>() {

    var data =  listOf<Card>()

    class CardHolder(view: View) : RecyclerView.ViewHolder(view){
        val questionTextView: TextView = itemView.findViewById(R.id.list_item_question)
        val answerTextView:TextView = itemView.findViewById(R.id.list_item_answer)
        val dateTextView: TextView = itemView.findViewById(R.id.list_item_date)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item_card, parent, false)
        return CardHolder(view)
    }

    override fun getItemCount() = data.size

    override fun onBindViewHolder(
        holder: CardHolder,
        position: Int
    ) {
        val item = data[position]
        (holder.itemView as TextView).text = "${item.question} \n ${item.answer}"
    }
}
