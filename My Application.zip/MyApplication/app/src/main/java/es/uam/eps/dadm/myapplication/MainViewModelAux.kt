package es.uam.eps.dadm.myapplication

import android.app.Application
import android.content.Context
import androidx.lifecycle.*
import es.uam.eps.dadm.myapplication.database.CardDatabase
import timber.log.Timber
import java.time.LocalDateTime
import java.util.concurrent.Executors

class MainViewModelAux(application: Application)  : AndroidViewModel(application) {
    private val executor = Executors.newSingleThreadExecutor()
    private val context = getApplication<Application>().applicationContext
    var dueCard: LiveData<Card?> = Transformations.map(cards) {
        it.filter { card -> card.isDue(LocalDateTime.now()) }.run {
            if (any()) random() else null
        }
    }

    val nDueCards: LiveData<Int>
        get() = _nDueCards
    var card: Card?
        get() = MainViewModelAux.card


    init {
        Timber.i("MainViewModel created")
        card = random_card()
        Timber.i((card!=null).toString())
        MainViewModelAux.context =
            getApplication<Application>().applicationContext
    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }




    fun update(quality: Int) {
        MainViewModelAux.card?.quality =  quality
        MainViewModelAux.card?.update(LocalDateTime.now())
        //_nDueCards.value = _nDueCards.value?.minus(1)
        //guardamos cambios en la base de datos
        executor.execute{
            CardDatabase.getInstance(context).cardDao.update(
                card = card!!
            )
        }
        //cambiamos carta
        MainViewModelAux.card = random_card()
    }

    companion object :ViewModel(){
        lateinit  var context: Context

        var card: Card? = null
        //private var cards: MutableList<Card> = CardsApplication.cards
        private var cards: LiveData<List<Card>> =CardDatabase.getInstance(context = context).cardDao.getCards()
        private val _nDueCards : LiveData<Int> = Transformations.map(cards) {
            it.filter { card -> card.isDue(LocalDateTime.now()) }.size
        }

        private fun dueCards(): List<Card> {
            return cards.value!!.filter {card ->  card.isDue(LocalDateTime.now())}
        }

        private fun random_card(): Card? {
            val aux = dueCards()
            if(aux.isEmpty()){
                return null
            }
            return aux.random()
        }

        fun update(){
            //_nDueCards.value = dueCards().size
            if(card==null) //si no había cards y ahora si
                card = random_card()
        }

        fun updDelCard(card: Card){
            //resto una a las cartas
            //_nDueCards.value = _nDueCards.value?.minus(1)
            if(this.card==card){ //si la que se elimina es la que tenía, la tiro
                this.card = random_card()
            }
        }
    }

}