package es.uam.eps.dadm.myapplication

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.*
import es.uam.eps.dadm.myapplication.databinding.FragmentStatisticsBinding


class StatisticsFragment
    :Fragment(){
    private val viewModel: StatisticsViewModel by lazy {
        ViewModelProvider(this)[StatisticsViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<FragmentStatisticsBinding>(
            inflater,
            R.layout.fragment_statistics,
            container,
            false
        )
        binding.viewModel = viewModel
        val chart: BarChart = binding.chart
        val barEntriesList = ArrayList<BarEntry>()
        val barEntriesList2 = ArrayList<BarEntry>()

        // on below line we are adding data
        // to our bar entries list
        for(i in 0..6) {
            barEntriesList.add(BarEntry(i.toFloat(), viewModel.cardsToReview[i].value?.toFloat()?:0f))
        }
        for(i in 0..3) {
            barEntriesList2.add(BarEntry(i.toFloat(), viewModel.cardsToReviewWeek[i].value?.toFloat()?:0f))
        }
        val pieEntriesList = ArrayList<PieEntry>()
        pieEntriesList.add(PieEntry( viewModel.nEassy.value?.toFloat()?:0f, context?.getString(R.string.easy_button_title)))
        pieEntriesList.add(PieEntry( viewModel.nDoubt.value?.toFloat()?:0f, context?.getString(R.string.doubt_button_title)))
        pieEntriesList.add(PieEntry( viewModel.nDifficult.value?.toFloat()?:0f, context?.getString(R.string.difficult_button_title)))
        val pieDataSet = PieDataSet(pieEntriesList, "")

        val colors =
            mutableListOf( Color.parseColor("#ff99cc00"), Color.parseColor("#ffffbb33"), Color.parseColor("#ffff4444"))

        pieDataSet.colors = colors
        pieDataSet.setValueTextColors(mutableListOf(Color.WHITE))

        val barDataSet = BarDataSet(barEntriesList, "Cards to Review")
        barDataSet.colors = mutableListOf(Color.parseColor("#ff99cc00"))
        val barDataSet2 = BarDataSet(barEntriesList2, "Cards to Review")
        barDataSet.colors = mutableListOf(Color.parseColor("#ffff4444"))
        binding.chart2.data=BarData(barDataSet2)
        chart.data = BarData(barDataSet)
        chart.data.setValueTextSize(15f)
        binding.chart2.data.setValueTextSize(15f)
        chart.legend.isEnabled = false
        binding.chart2.legend.isEnabled = false
        chart.description.isEnabled = false
        binding.chart2.description.isEnabled=false
        chart.xAxis.setDrawGridLines(false)
        binding.chart2.xAxis.setDrawGridLines(false)
        chart.xAxis.setDrawLabels(false)
        binding.chart2.xAxis.setDrawLabels(false)
        chart.xAxis.setDrawLimitLinesBehindData(false)
        binding.chart2.xAxis.setDrawLimitLinesBehindData(false)
        binding.pieChart.data = PieData(pieDataSet)
        binding.pieChart.data.setValueTextSize(15f)
        binding.pieChart.legend.textSize = 15f
        binding.pieChart.setEntryLabelTextSize(0f)
        binding.pieChart.animateY(1400, Easing.EaseInOutQuad)
        binding.apply { changeView.setOnClickListener {
            viewModel?.viewGrap1 = !((viewModel?.viewGrap1)?:false)
            invalidateAll()
        } }


        return binding.root
    }

}