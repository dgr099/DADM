package es.uam.eps.dadm.myapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import timber.log.Timber
import java.time.LocalDateTime
import java.time.DayOfWeek.SUNDAY
import java.time.temporal.TemporalAdjusters.next


class StatisticsViewModel : ViewModel() {
    var viewGrap1 : Boolean?=null
    init {
        viewGrap1 = true
        Timber.i("MainViewModel created")
    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }
    val totalReviewCards: LiveData<Int>
        get() = _cReviews
    val cardsToReview: MutableList<MutableLiveData<Int>>
        get() = _cardsToReview
    val cardsToReviewWeek: MutableList<MutableLiveData<Int>>
        get() = _cardsToReviewWeek
    val nDifficult: LiveData<Int>
        get() =  _difficult
    val nDoubt: LiveData<Int>
        get() =  _doubt
    val nEassy: LiveData<Int>
        get() =  _easy

    companion object :ViewModel(){
        private val _difficult = MutableLiveData<Int>()
        private val _doubt = MutableLiveData<Int>()
        private val _easy = MutableLiveData<Int>()
        private val _cReviews = MutableLiveData<Int>()

        private val _cardsToReview = mutableListOf<MutableLiveData<Int>>()
        private val _cardsToReviewWeek = mutableListOf<MutableLiveData<Int>>()
        init {
            _difficult.value = 0
            _doubt.value = 0
            _easy.value = 0
            _cReviews.value = 0
            for(i in 0..6){
                _cardsToReview.add(MutableLiveData<Int>())
                _cardsToReview[i].value = 0
            }
            for(i in 0..3){
                _cardsToReviewWeek.add(MutableLiveData<Int>())
                _cardsToReviewWeek[i].value = 0
            }

        }

        fun update(){
            for(i in 0..6) {
                _cardsToReview[i].value = CardsApplication.cards.filter { it.isDue(LocalDateTime.now().plusDays(i.toLong())) }.size
            }
            for(i in 0..3) {
                _cardsToReviewWeek[i].value = CardsApplication.cards.filter { it.isDue(LocalDateTime.now().plusWeeks(i.toLong())) }.size
            }
        }

        fun newCard(){

            for(i in 0..6) {
                val aux = _cardsToReview[i].value
                _cardsToReview[i].value = (aux ?: 0) + 1
            }
            for(i in 0..3) {
                val aux = _cardsToReviewWeek[i].value
                _cardsToReviewWeek[i].value = (aux?:0)+1
            }
        }

        fun remReview(date: LocalDateTime){
            for(i in 0..6) {
                if(LocalDateTime.now().plusDays(i.toLong()).isAfter(date) || LocalDateTime.now().plusDays(i.toLong()).isEqual(LocalDateTime.now())){
                    val aux = _cardsToReview[i].value
                    _cardsToReview[i].value = (aux?:0)-1
                }
            }

            for(i in 0..3) {
                if(LocalDateTime.now().with(next(SUNDAY)).plusWeeks(i.toLong()).isAfter(date) || date.with(next(SUNDAY)).plusWeeks(i.toLong()).isEqual(LocalDateTime.now())){
                    val aux = _cardsToReviewWeek[i].value
                    _cardsToReviewWeek[i].value = (aux?:0)-1
                }
                //_cardsToReviewWeek[i].value = CardsApplication.cards.filter { it.isDue(LocalDateTime.now().plusWeeks(i.toLong())) }.size
            }
        }
        fun addReview(quality: Int, date: LocalDateTime){
            when (quality) {
                5 -> _easy.value = (_easy.value?:0)+1
                3 ->  _doubt.value = (_doubt.value?:0)+1
                else->  _difficult.value = (_difficult.value?:0)+1
            }
            _cReviews.value = (_cReviews.value?:0)+1

            for(i in 0..6) {
                if(date.isAfter(LocalDateTime.now().plusDays(i.toLong())) || date.isEqual(LocalDateTime.now().plusDays(i.toLong()))){
                    val aux = _cardsToReview[i].value
                    _cardsToReview[i].value = (aux?:0)-1
                }
               //_cardsToReview[i].value = CardsApplication.cards.filter { it.isDue(LocalDateTime.now().plusDays(i.toLong())) }.size
                //_cardsToReview[i].value = CardsApplication.cards.filter { it.nextPracticeDate.isEqual(LocalDateTime.now().plusDays(i.toLong())) }.size
            }
            for(i in 0..3) {
                if(date.isAfter(LocalDateTime.now().with(next(SUNDAY)).plusWeeks(i.toLong())) || date.with(next(SUNDAY)).isEqual(LocalDateTime.now().plusWeeks(i.toLong()))){
                    val aux = _cardsToReviewWeek[i].value
                    _cardsToReviewWeek[i].value = (aux?:0)-1
                }
                //_cardsToReviewWeek[i].value = CardsApplication.cards.filter { it.isDue(LocalDateTime.now().plusWeeks(i.toLong())) }.size
            }
            }
        }
    }
