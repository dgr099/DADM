package es.uam.eps.dadm.myapplication

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import es.uam.eps.dadm.myapplication.database.CardDatabase

class CardListViewModel(application: Application)
    : AndroidViewModel(application) {

    private val context = getApplication<Application>().applicationContext

    // Completa la siguiente instrucción
    val cards: LiveData<List<Card>> = CardDatabase.getInstance(context).cardDao.getCards()
}