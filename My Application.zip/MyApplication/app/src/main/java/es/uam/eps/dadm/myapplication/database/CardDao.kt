package es.uam.eps.dadm.myapplication.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import es.uam.eps.dadm.myapplication.Card

@Dao
interface CardDao {
    @Query("SELECT * FROM cards_table")
    fun getCards(): LiveData<List<Card>>

    // Añade la función getCard
    @Query("SELECT * FROM cards_table WHERE id=:id_Card")
    fun getCard(id_Card: String): LiveData<Card?>
    @Insert
    fun addCard(card: Card)

    @Update
    fun update(card: Card)

    @Query("DELETE FROM cards_table")
    fun nukeTable();

}
