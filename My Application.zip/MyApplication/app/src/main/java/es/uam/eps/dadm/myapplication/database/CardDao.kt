package es.uam.eps.dadm.myapplication.database

import androidx.lifecycle.LiveData
import androidx.room.*
import es.uam.eps.dadm.myapplication.Card
import es.uam.eps.dadm.myapplication.Deck
import es.uam.eps.dadm.myapplication.DeckWithCards

@Dao
interface CardDao {
    @Query("SELECT * FROM cards_table")
    fun getCards(): LiveData<List<Card>>

    // Añade la función getCard
    @Query("SELECT * FROM cards_table WHERE id=:id_Card")
    fun getCard(id_Card: String): LiveData<Card?>
    @Insert
    fun addCard(card: Card)

    @Update
    fun update(card: Card)

    @Query("DELETE FROM cards_table")
    fun nukeTable();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun addDeck(deck: Deck)

    @Query("SELECT * FROM decks_table")
    fun getDecks(): LiveData<List<Deck>>

    @Transaction
    @Query("SELECT * FROM decks_table")
    fun getDecksWithCards(): LiveData<List<DeckWithCards>>

    @Transaction
    @Query("SELECT * FROM decks_table WHERE id = :deckId")
    fun getDeckWithCards(deckId: String): LiveData<List<DeckWithCards>>







}
