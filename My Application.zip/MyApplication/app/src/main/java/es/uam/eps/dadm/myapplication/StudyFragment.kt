package es.uam.eps.dadm.myapplication
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.get
import androidx.core.view.size
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import es.uam.eps.dadm.myapplication.databinding.FragmentStudyBinding
import java.time.LocalDateTime

class StudyFragment
    :Fragment(){
    private lateinit var binding: FragmentStudyBinding
    private val viewModel: MainViewModel by lazy {
        ViewModelProvider(this)[MainViewModel::class.java]
    }

    private var listener = View.OnClickListener { v ->
        // Asigna a quality el valor 0, 3 o 5,
        // dependiendo del botón que se haya pulsado
        val quality = when (v?.id) {
            binding.easyButton.id -> 5
            binding.doubtButton.id -> 3
            else-> 0 //boton hard
        }
        val card = viewModel.card
        viewModel.update(quality)
        StatisticsViewModel.addReview(quality, LocalDateTime.parse(card?.nextPracticeDate!!))
        if(viewModel.card==null){
            Toast.makeText(activity, "No more cards to study", Toast.LENGTH_SHORT).show()
        }
        binding.invalidateAll()
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_study,
            container,
            false)

        binding.viewModel = viewModel
        binding.apply {
            answerButton.setOnClickListener {
                viewModel?.card?.answered = true
                invalidateAll()
            }
        }
        for(button in 0 until binding.difficultyButtons.size){
            binding.difficultyButtons.get(button).setOnClickListener(
                listener
            )
        }


        return binding.root
    }

}