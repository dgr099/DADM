package es.uam.eps.dadm.myapplication

import android.annotation.SuppressLint
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.get
import androidx.core.view.size
import androidx.databinding.DataBindingUtil
import java.text.DecimalFormat
import java.time.LocalDateTime
import es.uam.eps.dadm.myapplication.databinding.ActivityMainBinding
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    var card : Card = Card(question="preg", answer="resp")
    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.card = card
        /*binding.answerButton.setOnClickListener {
            binding.answerTextView.visibility = View.VISIBLE
            binding.answerButton.visibility = View.INVISIBLE
            binding.difficultyButtons.visibility = View.VISIBLE
            binding.separatorView.visibility = View.VISIBLE
        }*/
        binding.answerButton.setOnClickListener {
            card?.answered = true
            binding.invalidateAll()
        }
        Timber.i("onCreate called")


        /*fun updCard(ind: Int){
            when(ind){
                0-> {card.quality=5
                    //Toast.makeText(this, "facil", Toast.LENGTH_SHORT).show()
                }
                1->{
                    card.quality=3
                    //Toast.makeText(this, "duda", Toast.LENGTH_SHORT).show()
                }
                2->{
                    card.quality=5
                    //Toast.makeText(this, "difícil", Toast.LENGTH_SHORT).show()
                }
                else->{
                    Toast.makeText(this, "error", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            card.update(LocalDateTime.now())
            Toast.makeText(this, "Eas: ${DecimalFormat("#.##").format(card.easiness) }", Toast.LENGTH_SHORT).show()

        }

        for(button in 0 until binding.difficultyButtons.size){
            binding.difficultyButtons[button].setOnClickListener{
                updCard(button)
            }
        }


        val name = resources.getString(R.string.app_name)

        //Toast.makeText(this, name, Toast.LENGTH_LONG).show()*/
    }
}