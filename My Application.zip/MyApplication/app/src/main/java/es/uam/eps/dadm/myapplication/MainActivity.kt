package es.uam.eps.dadm.myapplication

import android.annotation.SuppressLint
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.get
import androidx.core.view.size
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import java.text.DecimalFormat
import java.time.LocalDateTime
import es.uam.eps.dadm.myapplication.databinding.ActivityMainBinding
import timber.log.Timber
private const val ANSWERED_KEY = "es.uam.eps.dadm.cards:answered"
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by lazy {
        ViewModelProvider(this)[MainViewModel::class.java]
    }
    private var listener = View.OnClickListener { v ->
        // Asigna a quality el valor 0, 3 o 5,
        // dependiendo del botón que se haya pulsado
        val quality = when (v?.id) {
            binding.easyButton.id -> 5
            binding.doubtButton.id -> 3
            else-> 0 //boton hard
        }
        viewModel.update(quality)

        if(viewModel.card==null){
            Toast.makeText(this, "No more cards to study", Toast.LENGTH_SHORT).show()
        }


        binding.invalidateAll()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.viewModel = viewModel
        binding.apply {
            answerButton.setOnClickListener {
                viewModel?.card?.answered = true
                invalidateAll()
            }
        }
        for(button in 0 until binding.difficultyButtons.size){
            binding.difficultyButtons[button].setOnClickListener(
                listener
            )
        }

        /*binding.answerButton.setOnClickListener {
            binding.answerTextView.visibility = View.VISIBLE
            binding.answerButton.visibility = View.INVISIBLE
            binding.difficultyButtons.visibility = View.VISIBLE
            binding.separatorView.visibility = View.VISIBLE
        }*/
        /*binding.answerButton.setOnClickListener {
            Model.card.answered = true
            binding.invalidateAll()
        }*/
        //card.answered = savedInstanceState?.getBoolean(ANSWERED_KEY) ?: false

        Timber.i("onCreate called")


        /*fun updCard(ind: Int){
            when(ind){
                0-> {card.quality=5
                    //Toast.makeText(this, "facil", Toast.LENGTH_SHORT).show()
                }
                1->{
                    card.quality=3
                    //Toast.makeText(this, "duda", Toast.LENGTH_SHORT).show()
                }
                2->{
                    card.quality=5
                    //Toast.makeText(this, "difícil", Toast.LENGTH_SHORT).show()
                }
                else->{
                    Toast.makeText(this, "error", Toast.LENGTH_SHORT).show()
                    return
                }
            }
            card.update(LocalDateTime.now())
            Toast.makeText(this, "Eas: ${DecimalFormat("#.##").format(card.easiness) }", Toast.LENGTH_SHORT).show()

        }

        for(button in 0 until binding.difficultyButtons.size){
            binding.difficultyButtons[button].setOnClickListener{
                updCard(button)
            }
        }


        val name = resources.getString(R.string.app_name)

        //Toast.makeText(this, name, Toast.LENGTH_LONG).show()*/
    }


    override fun onStart() {
        super.onStart()
        Timber.i("onStart called")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Timber.i("onRestoreInstanceState called")

    }



    override fun onResume() {
        super.onResume()
        Timber.i("onResume called")
    }

    override fun onPause() {
        super.onPause()
        Timber.i("onPause called")
    }

    override fun onStop() {
        super.onStop()
        Timber.i("onStop called")

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Timber.i("onSaveInstanceState called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Timber.i("onDestroy called")
    }


}