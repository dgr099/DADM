package es.uam.eps.dadm.myapplication

import DeckAdapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import es.uam.eps.dadm.myapplication.databinding.FragmentDeckListBinding

class DeckListFragment: Fragment(){
    private lateinit var adapter: DeckAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<FragmentDeckListBinding>(
            inflater,
            R.layout.fragment_deck_list,
            container,
            false
        )
        adapter = DeckAdapter()
        adapter.data = CardsApplication.decks
        binding.deckListRecyclerView.adapter = adapter
        binding.newDeckFab.setOnClickListener{
            val deck = Deck("")
            CardsApplication.addDeck(deck)
            it.findNavController()
                .navigate(DeckListFragmentDirections.actionDeckListFragmentToCreateDeckFragment(deck.id))
        }
        /*binding.reviewButton.setOnClickListener { view ->
            if (CardsApplication.numberOfDueCards() > 0)
                view.findNavController()
                    .navigate(R.id.action_cardListFragment_to_studyFragment)
            else
                Toast.makeText(
                    requireActivity(),
                    R.string.no_more_cards_toast_message,
                    Toast.LENGTH_LONG
                ).show()
        }*/

        return binding.root
    }
}