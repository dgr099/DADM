package es.uam.eps.dadm.myapplication

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import es.uam.eps.dadm.myapplication.database.CardDatabase
import es.uam.eps.dadm.myapplication.databinding.FragmentCardEditBinding
import java.time.LocalDateTime
import java.util.concurrent.Executors

class CardEditFragment : Fragment() {
    lateinit var card: Card
    lateinit var binding: FragmentCardEditBinding
    private val executor = Executors.newSingleThreadExecutor()
    lateinit var question: String
    lateinit var answer: String
    private lateinit var deckId: String
    private val viewModel by lazy {
        ViewModelProvider(this)[CardEditViewModel::class.java]
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_card_edit,
            container,
            false
        )
        val args = CardEditFragmentArgs.fromBundle(requireArguments())
        viewModel.loadCardId(args.cardId)
        val decksID = mutableListOf<String>()
        val decksName = mutableListOf<String>()
        viewModel.card.observe(viewLifecycleOwner) {
            card = it!!
            binding.card = card
            question = card.question
            answer = card.answer
            CardDatabase.getInstance(requireContext()).cardDao.getDecks().observe(viewLifecycleOwner){
                it.forEach {
                    decksName.add(it.name)
                    decksID.add(it.id)
                    if(card.idDeck==it.id){
                        deckId=it.id
                    }
                }
                binding.spinner.setSelection(decksID.indexOf(deckId))
                binding.spinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, decksName)
            }
        }





        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                card.idDeck=decksID[position]
            }

        }
        binding.removeEditButtom.setOnClickListener {
            CardsApplication.cards.remove(card)
            findNavController().popBackStack()
        }
        return binding.root
    }
    override fun onStart() {
        super.onStart()

        val questionTextWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                card.question = s.toString()
            }

            override fun afterTextChanged(s: Editable?) {

            }
        }
        binding.questionEditText.addTextChangedListener(questionTextWatcher)

        val answerTextWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                card.answer = s.toString()
            }

            override fun afterTextChanged(s: Editable?) {

            }
        }
        binding.answerEditText.addTextChangedListener(answerTextWatcher)

        binding.acceptEditButtom.setOnClickListener {
            executor.execute{
                CardDatabase.getInstance(requireContext()).cardDao.update(
                    card = viewModel.card.value!!
                )
            }
            it.findNavController()
                    .navigate(R.id.action_cardEditFragment_to_cardListFragment2)
        }
        binding.cancelEditButtom.setOnClickListener { view ->
            /*card.answer=this.answer
            card.question=this.question
            card.idDeck=this.deckId*/
            view.findNavController()
                .navigate(R.id.action_cardEditFragment_to_cardListFragment2)
        }
    }
}