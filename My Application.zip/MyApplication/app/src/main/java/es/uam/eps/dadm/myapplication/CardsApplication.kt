package es.uam.eps.dadm.myapplication

import android.app.Application
import timber.log.Timber

class CardsApplication: Application() {

    init {
        cards.add(Card(question = "preg tarj 1", answer = "resp tarj 1"))
        cards.add(Card(question = "preg tarj 2", answer = "resp tarj 2"))
    }

    override fun onCreate() {
        super.onCreate()
        Timber.plant(Timber.DebugTree())
    }

    companion object {
        var cards: MutableList<Card> = mutableListOf<Card>()
    }
}