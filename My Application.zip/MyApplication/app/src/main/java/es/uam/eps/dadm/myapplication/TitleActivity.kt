package es.uam.eps.dadm.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import es.uam.eps.dadm.myapplication.databinding.ActivityTitleBinding
import timber.log.Timber

class TitleActivity : AppCompatActivity()/*,TitleFragment.OnTitleFragmentInteractionListener */{
    lateinit var binding: ActivityTitleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_title)
    }
}

    /*override fun onStudy() {
        this.supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, StudyFragment())
            .addToBackStack(null)
            .commit()

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_title)
        var fragment = supportFragmentManager
            .findFragmentById(R.id.fragment_container)

        if (fragment == null){
            fragment = TitleFragment()


            /*var aux = supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container, fragment)
                .commit()*/

            supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}*/

