package es.uam.eps.dadm.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import es.uam.eps.dadm.myapplication.databinding.ActivityTitleBinding

class TitleActivity : AppCompatActivity()/*,TitleFragment.OnTitleFragmentInteractionListener */{
    lateinit var binding: ActivityTitleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_title)
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.navHostFragment) as NavHostFragment
        binding.navView.setupWithNavController(navHostFragment.navController)
    }
}

    /*override fun onStudy() {
        this.supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragment_container, StudyFragment())
            .addToBackStack(null)
            .commit()

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_title)
        var fragment = supportFragmentManager
            .findFragmentById(R.id.fragment_container)

        if (fragment == null){
            fragment = TitleFragment()


            /*var aux = supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container, fragment)
                .commit()*/

            supportFragmentManager
                .beginTransaction()
                .add(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}*/

