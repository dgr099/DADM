package es.uam.eps.dadm.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import es.uam.eps.dadm.myapplication.databinding.ActivityMainBinding
import es.uam.eps.dadm.myapplication.databinding.ActivityTitleBinding

class TitleActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTitleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_title)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_title)

    //binding = DataBindingUtil.setContentView(this, R.layout.activity_title)
        /*binding.apply {
            answerButton.setOnClickListener {
                viewModel?.card?.answered = true
                invalidateAll()
            }*/
        }
    }