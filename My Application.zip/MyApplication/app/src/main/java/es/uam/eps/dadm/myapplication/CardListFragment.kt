package es.uam.eps.dadm.myapplication

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import es.uam.eps.dadm.myapplication.database.CardDatabase
import es.uam.eps.dadm.myapplication.databinding.FragmentCardListBinding

class CardListFragment: Fragment(){
    private val cardListViewModel by lazy {
        ViewModelProvider(this)[CardListViewModel::class.java]
    }
    private lateinit var adapter: CardAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<FragmentCardListBinding>(
            inflater,
            R.layout.fragment_card_list,
            container,
            false
        )
        adapter = CardAdapter()
        adapter.data = emptyList()
        binding.cardListRecyclerView.adapter = adapter
        binding.newCardFab.setOnClickListener{
            if(CardsApplication.decks.size<1){
                Toast.makeText(
                    requireActivity(),
                    R.string.no_decks,
                    Toast.LENGTH_LONG
                ).show()
            }else{
                val card = Card("", "")
                card.idDeck=CardsApplication.decks.first().id
                /*CardsApplication.addCard(card)
                MainViewModel.update()*/
                CardDatabase.getInstance(requireContext()).cardDao.addCard(card)
                it.findNavController()
                    .navigate(CardListFragmentDirections.actionCardListFragmentToCardEditFragment(card.id))
            }
        }
        cardListViewModel.cards.observe(viewLifecycleOwner) {
            adapter.data = it
            adapter.notifyDataSetChanged()
        }

        /*binding.reviewButton.setOnClickListener { view ->
            if (CardsApplication.numberOfDueCards() > 0)
                view.findNavController()
                    .navigate(R.id.action_cardListFragment_to_studyFragment)
            else
                Toast.makeText(
                    requireActivity(),
                    R.string.no_more_cards_toast_message,
                    Toast.LENGTH_LONG
                ).show()
        }*/

        return binding.root
    }
}