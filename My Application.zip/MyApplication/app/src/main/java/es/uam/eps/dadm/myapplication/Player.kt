package es.uam.eps.dadm.myapplication

import timber.log.Timber
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner


class Player(lifecycle: Lifecycle): DefaultLifecycleObserver {
    init {
        lifecycle.addObserver(this)
    }
    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        start()
    }

    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        stop()
    }

    fun start() {
        Timber.i("start player")
    }
    fun stop() {
        Timber.i("stop player")
    }
}
