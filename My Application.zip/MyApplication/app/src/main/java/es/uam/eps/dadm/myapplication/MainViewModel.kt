package es.uam.eps.dadm.myapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import timber.log.Timber
import java.time.LocalDateTime

class MainViewModel : ViewModel() {

    val nDueCards: LiveData<Int>
        get() = _nDueCards
    var card: Card?
        get() = MainViewModel.card

    init {
        Timber.i("MainViewModel created")
        _nDueCards.value = dueCards().size
        card = random_card()
        Timber.i((card!=null).toString())

    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }




    fun update(quality: Int) {
        MainViewModel.card?.quality =  quality
        MainViewModel.card?.update(LocalDateTime.now())
        _nDueCards.value = _nDueCards.value?.minus(1)
        MainViewModel.card = random_card()
    }
    companion object :ViewModel(){
        var card: Card? = null
        private var cards: MutableList<Card> = CardsApplication.cards
        private val _nDueCards = MutableLiveData<Int>()
        private fun dueCards(): List<Card> {
            return cards.filter {card ->  card.isDue(LocalDateTime.now())}
        }
        private fun random_card(): Card? {
            val aux = dueCards()
            if(aux.isEmpty()){
                return null
            }
            return aux.random()
        }
        fun update(){
            _nDueCards.value = dueCards().size
            if(card==null)
                card = random_card()
        }
        fun updDelCard(card: Card){
            //resto una a las cartas
            _nDueCards.value = _nDueCards.value?.minus(1)
            if(this.card==card){ //si la que se elimina es la que tenía, la tiro
                this.card = random_card()
            }
        }
    }

}