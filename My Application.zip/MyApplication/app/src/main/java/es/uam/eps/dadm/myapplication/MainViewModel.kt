package es.uam.eps.dadm.myapplication

import android.app.Application
import android.content.Context
import androidx.lifecycle.*
import es.uam.eps.dadm.myapplication.database.CardDatabase
import timber.log.Timber
import java.time.LocalDateTime
import java.util.concurrent.Executors

class MainViewModel(application: Application)  : AndroidViewModel(application) {
    private val executor = Executors.newSingleThreadExecutor()
    private val context = getApplication<Application>().applicationContext
    private val cards: LiveData<List<CardsWithMultiple>> =CardDatabase.getInstance(context = context).cardDao.getCardsWithMult()

    var dueCard: LiveData<CardsWithMultiple?> = Transformations.map(cards) {
        it.filter {it.card.isDue(LocalDateTime.now()) }.run {
            if (any()) random() else null
        }
    }



    val nDueCards : LiveData<Int> = Transformations.map(cards) {
        it.filter {it.card.isDue(LocalDateTime.now())}.size
    }



    var card: Card? = null
    var mult: MultipleOption? = null


    private fun random_card(): CardsWithMultiple? {
        val aux = dueCards()
        if(aux.isEmpty()){
            return null
        }
        return aux.random()
    }

    private fun dueCards(): List<CardsWithMultiple> {
        return cards.value!!.filter {it.card.isDue(LocalDateTime.now())}
    }

    init {
        Timber.i("MainViewModel created")
        //card = random_card()
        //card = dueCard.value
        Timber.i((card!=null).toString())

    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }




    fun update(quality: Int) {
        var auxCard: Card? = null
        if(mult!=null){
            auxCard=mult
        }else{
            auxCard=card
        }
        auxCard?.quality =  quality
        auxCard?.update(LocalDateTime.now())
        //_nDueCards.value = _nDueCards.value?.minus(1)
        //guardamos cambios en la base de datos
        executor.execute{

            CardDatabase.getInstance(context).cardDao.updateCard(
                card = auxCard!!
            )
            if(auxCard is MultipleOption){
                CardDatabase.getInstance(context).cardDao.updateMult(
                    multipleOption = auxCard
                )
            }

        }
        //cambiamos carta
        var aux = random_card()
        card = aux?.card
        mult = aux?.mult
    }


}