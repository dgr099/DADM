package es.uam.eps.dadm.myapplication

import android.app.Application
import android.content.Context
import androidx.lifecycle.*
import es.uam.eps.dadm.myapplication.database.CardDatabase
import timber.log.Timber
import java.time.LocalDateTime
import java.util.concurrent.Executors

class MainViewModel(application: Application)  : AndroidViewModel(application) {
    private val executor = Executors.newSingleThreadExecutor()
    private val context = getApplication<Application>().applicationContext
    private val cards: LiveData<List<Card>> =CardDatabase.getInstance(context = context).cardDao.getCards()

    var dueCard: LiveData<Card?> = Transformations.map(cards) {
        it.filter { card -> card.isDue(LocalDateTime.now()) }.run {
            if (any()) random() else null
        }
    }



    val nDueCards : LiveData<Int> = Transformations.map(cards) {
        it.filter { card -> card.isDue(LocalDateTime.now()) }.size
    }



    var card: Card? = null



    private fun random_card(): Card? {
        val aux = dueCards()
        if(aux.isEmpty()){
            return null
        }
        return aux.random()
    }

    private fun dueCards(): List<Card> {
        return cards.value!!.filter { card ->  card.isDue(LocalDateTime.now())}
    }

    init {
        Timber.i("MainViewModel created")
        //card = random_card()
        //card = dueCard.value
        Timber.i((card!=null).toString())

    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }




    fun update(quality: Int) {
        card?.quality =  quality
        card?.update(LocalDateTime.now())
        //_nDueCards.value = _nDueCards.value?.minus(1)
        //guardamos cambios en la base de datos
        executor.execute{
            CardDatabase.getInstance(context).cardDao.update(
                card = card!!
            )
        }
        //cambiamos carta
        card = random_card()
    }


}