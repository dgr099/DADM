package es.uam.eps.dadm.myapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import timber.log.Timber
import java.time.LocalDateTime

class MainViewModel : ViewModel() {
    var card: Card? = null
    private var cards: MutableList<Card> = CardsApplication.cards
    private val _nDueCards = MutableLiveData<Int>()
    val nDueCards: LiveData<Int>
        get() = _nDueCards

    init {
        Timber.i("MainViewModel created")
        _nDueCards.value = dueCards().size
        card = random_card()
        Timber.i((card!=null).toString())

    }

    override fun onCleared() {
        super.onCleared()
        Timber.i("MainViewModel destroyed")
    }
    private fun dueCards(): List<Card> {
        return cards.filter {card ->  card.isDue(LocalDateTime.now())}
    }

    private fun random_card(): Card? {
        val aux = dueCards()
        if(aux.isEmpty()){
            return null
        }
        return aux.random()
    }

    fun update(quality: Int) {
        card?.quality =  quality
        card?.update(LocalDateTime.now())
        _nDueCards.value = _nDueCards.value?.minus(1)
        card = random_card()
    }

}